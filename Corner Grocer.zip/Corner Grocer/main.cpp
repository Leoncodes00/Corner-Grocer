#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ItemTracker {
public:
    //Function that reads the data file and updates the item frequency map
    void readDataFile();
    //Function that displays the menu options and calls the appropriate menu function based on the user's input
    void displayMenu();
private:
    map<string, int> itemFrequency;
    //Function that prompts the user to enter an item and displays the frequency of that item
    void searchItem();
    //Function that displays and prints each item's name and its frequency count
    void printFrequencyList();
    //Function that displays a histogram of the item's frequencies
    void printHistogram();
};

void ItemTracker::readDataFile() {
    //Reads the input file and stores each item's frequency count in the itemFrequency map
    ifstream dataFile("CS210_Project_Three_Input_File.txt");
    string item;
    while (dataFile >> item) {
        itemFrequency[item]++;
    }
    dataFile.close();
}

void ItemTracker::displayMenu() {
    //Displays menu options
    int choice;
    do {
        cout << "\nMenu\n";
        cout << "1. Search for an item\n";
        cout << "2. Print the frequency list\n";
        cout << "3. Print a histogram\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            searchItem();
            break;
        case 2:
            printFrequencyList();
            break;
        case 3:
            printHistogram();
            break;
        case 4:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 4);
}

void ItemTracker::searchItem() {
    //Prompts user to enter the item name and then checks if that item exists in the itemFrequency map
    string item;
    cout << "Enter the item to search for: ";
    cin >> item;
    if (itemFrequency.find(item) == itemFrequency.end()) {
        cout << item << " not found.\n";
    }
    else {
        cout << "Frequency of " << item << " = " << itemFrequency[item] << endl;
    }
}

void ItemTracker::printFrequencyList() {
    //Iterates over the item frequency map and prints each item's name and its frequency count
    cout << "Frequency list:\n";
    for (auto const& item : itemFrequency) {
        cout << item.first << " " << item.second << endl;
    }
}

void ItemTracker::printHistogram() {
    //Iterates iver the item frequency map and prints a histogram of each item's frequency count using an asterisk(*) for each count
    cout << "Histogram:\n";
    for (auto const& item : itemFrequency) {
        cout << item.first << " ";
        for (int i = 0; i < item.second; i++) {
            cout << "*";
        }
        cout << endl;
    }
}

int main() {
    //Creates an instance of the itemTracker class, reads data from the input file using the readDataFile() function, and
    //displays the menu to the user using the displayMenu() function
    //The user can then select one of the options from the menu to search for an item, print the frequency list, print a histogram, or exit the program.
    ItemTracker itemTracker;
    itemTracker.readDataFile();
    itemTracker.displayMenu();
    return 0;
}